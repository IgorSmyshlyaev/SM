import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Cards {
    private final Scanner scanner = new Scanner(System.in);
    private final Random random = new Random();
    private final List<String> arrayDeck = new ArrayList<>();
    private String[][] gamer;
    private final String[] suit = {"R", "G", "B", "W"};

    public void start() {
        while (true) {
            System.out.println("""
                    \nВведите команду
                    (доступны "start N C" - раздача N карт C игрокам
                    "get-cards C" - вывод списка карт игрока № C
                    "exit" - выход из приложения)""");
            String input = scanner.nextLine();
            if (input.contains("start")) {
                startCommand(input);
            } else if (input.contains("get-cards")) {
                getCardsCommand(input);
            } else if (input.contains("exit")) {
                System.out.println("End Game");
                return;
            } else {
                System.out.println("\033[91mНераспознанная команда, повторите ввод\033[0m");
            }
        }
    }

    // команда start N C
    private void startCommand(String commandFull) {
        fillDeck();

        String[] commands = commandFull.split(" ");
        int n;
        int c;

        try {
            n = Integer.parseInt(commands[1]);
            c = Integer.parseInt(commands[2]);
        } catch (ArrayIndexOutOfBoundsException ex) {
            System.out.println("Введены недопустимые параметры команды");
            return;
        }
        if (n * c <= arrayDeck.size()) {
            dialCards(n, c);
            System.out.println("Карты розданы игрокам. Игра началась...");
        } else {
            System.out.println("\033[91mНе хватит карт. Введите ещё раз количество игроков и карт.\033[0m");
        }
    }

    // команда "get-cards C"
    private void getCardsCommand(String commandFull) {
        int c;

        if (arrayDeck.size() == 0) {
            System.out.println("\033[91mУ игроков нет карт, раздайте сначала (команда start).\033[0m");
            return;
        }
        String[] commands = commandFull.split(" ");
        try {
            c = Integer.parseInt(commands[1]);
        } catch (ArrayIndexOutOfBoundsException ex) {
            System.out.println("\033[91mВведены недопустимые параметры команды\033[0m");
            return;
        }
        if (c > gamer[0].length) {
            System.out.println("\033[91mУ нас игроков всего " + (gamer[0].length) + ", введён неправильный параметр\033[0m");
            return;
        } else if (c < 1) {
            System.out.println("\033[91mПараметр команды get-cards должен быть от 1 до " + gamer[0].length + "\033[0m");
            return;
        }
        printCards((c - 1));
    }

    // заполнение колоды
    private void fillDeck() {
        arrayDeck.clear();
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j < 10; j++) {
                arrayDeck.add((suit[i] + (j + 1)));
            }
        }
    }

    // раздача карт
    private void dialCards(int countCards, int countPlayers) {
        gamer = new String[countCards][countPlayers];

        if (countCards * countPlayers <= arrayDeck.size()) { //Проверяем хватит ли карт

            for (int i = 0; i < countCards; i++) { //перебираем игроков
                for (int j = 0; j < countPlayers; j++) { //даём по одной карте каждому игроку
                    gamer[i][j] = arrayDeck.remove(random.nextInt(0, arrayDeck.size()));
                }
            }

        } else {
            System.out.println("\033[91mНе хватит карт. Введите ещё раз количество игроков и карт.\033[0m");
        }
    }

    private void printCards(int countPlayers) {
        System.out.println("\033[93m\nУ игрока №" + (countPlayers + 1) + " следующие карты:");

        for (String[] strings : gamer) {
            System.out.print(strings[countPlayers] + " ");
        }

        System.out.println("\033[0m");
    }
}
